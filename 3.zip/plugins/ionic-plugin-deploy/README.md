## Ionic Deploy Plugin

The Cordova plugin for Ionic Deploy.

Check out our [docs](http://docs.ionic.io/docs/io-introduction) for more detailed information.

## Installation

Using the latest [Ionic CLI](https://github.com/driftyco/ionic-cli):

Run the following commands in terminal:

```bash
# first you need to install the web client
$ ionic add ionic-platform-web-client

# now you can register your app with the platform
$ ionic io init

# now you can install the plugin
$ ionic plugin add ionic-plugin-deploy
```
