
0.0.13 / 2015-07-22
===================

  * New dist

0.0.12 / 2015-07-22
===================

  * Merge pull request #36 from jercoh/detect-sessionStorage
  * fix(sessionStorage): proper detect sessionStorage
  * Merge pull request #31 from ako977/master
  * Fix for #30: Proper handling of localStorage disabled check

0.0.11 / 2015-05-18
===================

  * Merge pull request #28 from aaronroberson/master
  * Added support for Browserify/Webpack

0.0.10 / 2015-04-17
===================

  * Fixed private browsing error
  * Merge pull request #23 from joshuabc/package-json-main
  * Add `main` to package.json. Allows package to be required directly in Browserify environments.
  * Merge pull request #20 from 4kochi/master
  * test: add code coverage specific karma settings to the gulpfile
  * add code coverage task `gulp cover`
  * change store service to a provider
  * remove storage.js file, not needed any more
  * fix dist tests
  * add method setStorage() to the store service
  * add gulp task test-all to run the unit tests in all available browsers on the current system
  * also check gulpfile.js for jshint errors
  * fix jshint warnings
  * add lint task to gulp to check for jshint errors/warnings
  * changer version of angular-cookies in bower.json to fix resolution error when running bower install
  * add field repository to package.json to fix npm warning
  * Merge pull request #18 from kildareflare/fixCookies
  * add newly built dist files
  * remove ngCookie dependency and code tidy up after review
  * add cookie dependency to bower json
  * add missing ngCookie depednency. add missing test for cookie fallback
  * Update and rename LICENSE to LICENSE.txt
  * Updated CDN link

0.0.6 / 2014-10-08
==================

  * Added dist files I forgot

0.0.5 / 2014-10-08
==================

  * Added namespaced stores

0.0.4 / 2014-10-07
==================

  * New dist files

0.0.3 / 2014-10-07
==================

  * Added fixes asked by @matjaz.
  * Update README.md
  * Update bower.json
  * Update README.md
  * Update README.md
  * 0.0.2
  * Added dist ngAnnotate
